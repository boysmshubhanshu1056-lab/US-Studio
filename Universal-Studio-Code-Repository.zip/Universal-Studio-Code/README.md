# Universal Studio Code — US- Code

A dark-emerald native iPad coding workspace built with SwiftUI.

## Included in this starter build

- Native iPad SwiftUI interface
- Dark emerald theme
- Local project storage (up to 100 projects)
- HTML, JavaScript, Python, Lua and Roblox Luau project templates
- Monospaced editor with line numbers
- Import UTF-8 source files from the Files app
- Export the selected source file back to Files
- Interactive HTML preview powered by WebKit
- JavaScript preview with `console.log` output shown in the page
- GitHub Actions workflow that builds an unsigned iOS IPA

## Runtime status — important

This initial repository executes HTML and JavaScript in WebKit. Python, Lua and Luau files can be created, edited, imported, saved and exported, but their interpreters are **not bundled yet**. Roblox APIs such as `game:GetService()` require a Roblox runtime and are not available in a normal iPad app.

Future runtime integration:
- Python: embed a compatible iOS Python distribution.
- Lua: embed a Lua VM compiled for iOS.
- Luau: integrate the Luau VM and its iOS build.
These runtimes need separate build, licensing, app-size and compatibility work. The editor does not fake execution.

## Repository structure

```text
USCode/
  USCodeApp.swift
  Models/
    CodeLanguage.swift
    CodeFile.swift
    CodeProject.swift
  Storage/
    ProjectStore.swift
  Services/
    CodeFileDocument.swift
  Components/
    CodeEditorView.swift
  Views/
    DashboardView.swift
    NewProjectView.swift
    ProjectEditorView.swift
    HTMLPreviewView.swift
.github/workflows/ios-build.yml
project.yml
```

## Build from GitHub on iPad

1. Create a GitHub repository named `Universal-Studio-Code`.
2. Upload the contents of this repository to the repository root. Keep `.github/workflows/ios-build.yml` at that exact path.
3. Open the repository's **Actions** tab.
4. Select **Build US- Code for iPad**.
5. Tap **Run workflow** (or push a commit to `main` / `master`).
6. When the run succeeds, open the run and download the `US-Code-unsigned-IPA` artifact.

## Installation targets

The workflow produces an **unsigned** IPA. It is a build artifact, not a directly installable signed app. SideStore and AltStore generally re-sign imported apps using their supported workflow. LiveContainer has its own compatibility and signing requirements. A single unsigned artifact is not guaranteed to work identically in all three; capabilities, entitlements and iOS version restrictions can differ.

Never add Apple certificates or provisioning profiles to a public repository. If a future workflow signs the app, use private GitHub Actions secrets and a provisioning profile matching the bundle identifier.

## App identity

- Display name: `US- Code`
- Product name: `US- Code`
- Bundle identifier: `com.uscode.editor` (provisional)
- Minimum deployment target: iOS 16.0

## Current limitations

- This is a working starter editor, not yet a full IDE.
- Syntax highlighting, autocomplete, breakpoints and debugger are not implemented.
- File import currently imports one UTF-8 text file at a time; folder and ZIP import/export are not implemented yet.
- JavaScript runs in WebKit, not Node.js. Node modules and native packages are not available.
