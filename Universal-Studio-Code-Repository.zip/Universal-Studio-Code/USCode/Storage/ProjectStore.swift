import Foundation
import Combine

@MainActor
final class ProjectStore: ObservableObject {
    @Published private(set) var projects: [CodeProject] = []
    let projectLimit = 100

    private var storageURL: URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("uscode-projects.json")
    }

    init() { load() }

    func project(withID id: UUID) -> CodeProject? {
        projects.first { $0.id == id }
    }

    @discardableResult
    func createProject(name: String, language: CodeLanguage) -> Bool {
        guard projects.count < projectLimit else { return false }
        let cleaned = name.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !cleaned.isEmpty else { return false }
        projects.insert(.starter(name: cleaned, language: language), at: 0)
        persist()
        return true
    }

    func deleteProjects(at offsets: IndexSet) {
        projects.remove(atOffsets: offsets)
        persist()
    }

    func updateFile(projectID: UUID, fileID: UUID, content: String) {
        guard let p = projects.firstIndex(where: { $0.id == projectID }),
              let f = projects[p].files.firstIndex(where: { $0.id == fileID }) else { return }
        projects[p].files[f].content = content
        projects[p].modifiedAt = Date()
        persist()
    }

    func addFile(projectID: UUID, file: CodeFile) {
        guard let p = projects.firstIndex(where: { $0.id == projectID }),
              !projects[p].files.contains(where: { $0.name == file.name }) else { return }
        projects[p].files.append(file)
        projects[p].modifiedAt = Date()
        persist()
    }

    private func load() {
        do {
            let data = try Data(contentsOf: storageURL)
            projects = try JSONDecoder().decode([CodeProject].self, from: data)
        } catch {
            projects = []
        }
    }

    private func persist() {
        do {
            let data = try JSONEncoder().encode(projects)
            try data.write(to: storageURL, options: [.atomic])
        } catch {
            print("US- Code save error: \(error)")
        }
    }
}
