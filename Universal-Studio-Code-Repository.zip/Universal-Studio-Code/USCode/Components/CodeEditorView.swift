import SwiftUI

struct CodeEditorView: View {
    @Binding var text: String

    var body: some View {
        HStack(alignment: .top, spacing: 0) {
            ScrollView {
                VStack(alignment: .trailing, spacing: 0) {
                    ForEach(1...max(1, text.components(separatedBy: "\n").count), id: \.self) { line in
                        Text("\(line)")
                            .font(.system(size: 13, design: .monospaced))
                            .foregroundStyle(Color.white.opacity(0.28))
                            .frame(minHeight: 20)
                    }
                }
                .padding(.horizontal, 9).padding(.top, 10)
            }
            .frame(width: 42)
            TextEditor(text: $text)
                .font(.system(size: 14, design: .monospaced))
                .foregroundStyle(Color(red: 0.83, green: 0.95, blue: 0.88))
                .scrollContentBackground(.hidden).autocorrectionDisabled()
                .textInputAutocapitalization(.never).padding(.top, 2)
        }
        .background(Color(red: 0.035, green: 0.075, blue: 0.055))
    }
}
