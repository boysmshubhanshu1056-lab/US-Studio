import Foundation

enum CodeLanguage: String, CaseIterable, Identifiable, Codable {
    case html = "HTML"
    case javascript = "JavaScript"
    case python = "Python"
    case lua = "Lua"
    case luau = "Roblox Luau"

    var id: String { rawValue }

    var fileExtension: String {
        switch self {
        case .html: return "html"
        case .javascript: return "js"
        case .python: return "py"
        case .lua: return "lua"
        case .luau: return "luau"
        }
    }

    var starterCode: String {
        switch self {
        case .html:
            return """
            <!doctype html>
            <html>
            <head>
              <meta name="viewport" content="width=device-width, initial-scale=1">
              <title>My page</title>
              <style>
                body { font-family: system-ui; padding: 24px; background: #101b16; color: white; }
                button { padding: 12px 18px; border: 0; border-radius: 10px; background: #10b981; color: #04130d; }
              </style>
            </head>
            <body>
              <h1>Hello, US- Code!</h1>
              <button onclick="document.querySelector('p').textContent = 'It works!'">Tap me</button>
              <p>Interactive preview is ready.</p>
            </body>
            </html>
            """
        case .javascript:
            return "console.log('Hello from JavaScript!');"
        case .python:
            return "print('Hello from Python!')"
        case .lua:
            return "print('Hello from Lua!')"
        case .luau:
            return "print('Hello from Roblox Luau!')"
        }
    }
}
