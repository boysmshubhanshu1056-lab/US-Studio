import Foundation

struct CodeProject: Identifiable, Codable, Equatable {
    var id: UUID = UUID()
    var name: String
    var language: CodeLanguage
    var createdAt: Date = Date()
    var modifiedAt: Date = Date()
    var files: [CodeFile]

    static func starter(name: String, language: CodeLanguage) -> CodeProject {
        let file = CodeFile(
            name: "main.\(language.fileExtension)",
            language: language,
            content: language.starterCode
        )
        return CodeProject(name: name, language: language, files: [file])
    }
}
