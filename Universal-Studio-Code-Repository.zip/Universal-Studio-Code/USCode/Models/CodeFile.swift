import Foundation

struct CodeFile: Identifiable, Codable, Equatable {
    var id: UUID = UUID()
    var name: String
    var language: CodeLanguage
    var content: String

    var fileExtension: String {
        let ext = (name as NSString).pathExtension
        return ext.isEmpty ? language.fileExtension : ext
    }
}
