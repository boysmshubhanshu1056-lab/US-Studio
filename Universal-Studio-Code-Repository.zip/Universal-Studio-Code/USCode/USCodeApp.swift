import SwiftUI

@main
struct USCodeApp: App {
    @StateObject private var projectStore = ProjectStore()

    var body: some Scene {
        WindowGroup {
            DashboardView()
                .environmentObject(projectStore)
                .preferredColorScheme(.dark)
        }
    }
}
