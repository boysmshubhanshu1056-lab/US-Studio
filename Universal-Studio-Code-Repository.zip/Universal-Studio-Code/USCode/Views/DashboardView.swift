import SwiftUI

struct DashboardView: View {
    @EnvironmentObject private var store: ProjectStore
    @State private var showingNewProject = false

    private let emerald = Color(red: 16/255, green: 185/255, blue: 129/255)

    var body: some View {
        NavigationStack {
            ZStack {
                Color(red: 11/255, green: 23/255, blue: 18/255).ignoresSafeArea()
                VStack(alignment: .leading, spacing: 20) {
                    HStack {
                        VStack(alignment: .leading, spacing: 5) {
                            Text("UNIVERSAL STUDIO")
                                .font(.caption.weight(.bold)).tracking(2).foregroundStyle(emerald)
                            Text("US- Code")
                                .font(.system(size: 34, weight: .bold, design: .rounded)).foregroundStyle(.white)
                            Text("Your code. Your workspace.").foregroundStyle(.white.opacity(0.6))
                        }
                        Spacer()
                        Image(systemName: "chevron.left.forwardslash.chevron.right")
                            .font(.system(size: 27, weight: .bold)).foregroundStyle(emerald)
                            .padding(16).background(emerald.opacity(0.12), in: RoundedRectangle(cornerRadius: 18))
                    }

                    HStack {
                        Label("\(store.projects.count)/\(store.projectLimit) projects", systemImage: "folder")
                        Spacer()
                        Button {
                            showingNewProject = true
                        } label: {
                            Label("New project", systemImage: "plus")
                                .font(.subheadline.bold()).padding(.horizontal, 14).padding(.vertical, 10)
                                .background(emerald, in: Capsule()).foregroundStyle(Color.black)
                        }
                    }
                    .foregroundStyle(.white)

                    if store.projects.isEmpty {
                        Spacer()
                        VStack(spacing: 14) {
                            Image(systemName: "curlybraces").font(.system(size: 48)).foregroundStyle(Color.green)
                            Text("Start building something").font(.title3.bold()).foregroundStyle(.white)
                            Text("Create your first project and write some code.")
                                .multilineTextAlignment(.center).foregroundStyle(.white.opacity(0.6))
                            Button("Create project") { showingNewProject = true }
                                .buttonStyle(.borderedProminent).tint(emerald)
                        }
                        Spacer()
                    } else {
                        List {
                            ForEach(store.projects) { project in
                                NavigationLink {
                                    ProjectEditorView(projectID: project.id)
                                } label: {
                                    HStack(spacing: 13) {
                                        Image(systemName: "chevron.left.forwardslash.chevron.right")
                                            .font(.title3).foregroundStyle(emerald)
                                            .frame(width: 42, height: 42)
                                            .background(emerald.opacity(0.12), in: RoundedRectangle(cornerRadius: 12))
                                        VStack(alignment: .leading, spacing: 4) {
                                            Text(project.name).font(.headline).foregroundStyle(.white)
                                            Text("\(project.language.rawValue) • \(project.files.count) file(s)")
                                                .font(.caption).foregroundStyle(.white.opacity(0.55))
                                        }
                                    }
                                    .padding(.vertical, 5)
                                }
                                .listRowBackground(Color.white.opacity(0.045))
                            }
                            .onDelete(perform: store.deleteProjects)
                        }
                        .scrollContentBackground(.hidden).listStyle(.insetGrouped)
                    }
                }
                .padding(.horizontal, 18).padding(.top, 16)
            }
            .toolbar(.hidden, for: .navigationBar)
            .sheet(isPresented: $showingNewProject) {
                NewProjectView().environmentObject(store)
            }
        }
        .tint(emerald)
    }
}
