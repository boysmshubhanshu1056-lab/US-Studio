import SwiftUI

struct NewProjectView: View {
    @EnvironmentObject private var store: ProjectStore
    @Environment(\.dismiss) private var dismiss
    @State private var name = ""
    @State private var language: CodeLanguage = .html
    @State private var showLimitAlert = false

    var body: some View {
        NavigationStack {
            Form {
                Section("Project details") {
                    TextField("Project name", text: $name)
                    Picker("Language", selection: $language) {
                        ForEach(CodeLanguage.allCases) { item in Text(item.rawValue).tag(item) }
                    }
                }
                Section {
                    Text("Projects are stored locally on this iPad. Maximum: 100.")
                        .font(.footnote).foregroundStyle(.secondary)
                }
            }
            .navigationTitle("New project").navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Create") {
                        if store.createProject(name: name, language: language) {
                            dismiss()
                        } else {
                            showLimitAlert = true
                        }
                    }
                    .disabled(name.trimmingCharacters(in: .whitespaces).isEmpty)
                }
            }
            .alert("Project limit reached", isPresented: $showLimitAlert) {
                Button("OK", role: .cancel) {}
            } message: {
                Text("US- Code can store up to 100 projects.")
            }
        }
        .preferredColorScheme(.dark)
    }
}
