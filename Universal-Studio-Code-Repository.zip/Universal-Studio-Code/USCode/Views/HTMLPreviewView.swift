import SwiftUI
import WebKit

struct HTMLPreviewView: View {
    let source: String
    let language: CodeLanguage
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            PreviewWebView(html: makeHTML())
                .background(Color.white)
                .navigationTitle("Live Preview")
                .navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .confirmationAction) {
                        Button("Done") { dismiss() }
                    }
                }
        }
        .preferredColorScheme(.dark)
    }

    private func makeHTML() -> String {
        if language == .html { return source }
        let safeSource = source.replacingOccurrences(of: "</script>", with: "<\\/script>")
        return """
        <!doctype html>
        <html><head><meta name="viewport" content="width=device-width, initial-scale=1">
        <style>body{font-family:system-ui;padding:20px;background:#101b16;color:#e8fff2}
        pre{white-space:pre-wrap;background:#07110c;padding:12px;border-radius:10px}</style>
        </head><body><h2>JavaScript Preview</h2><div id="output"></div>
        <script>
        const output = document.getElementById('output');
        const originalLog = console.log;
        console.log = (...args) => {
          const line = document.createElement('pre');
          line.textContent = args.map(String).join(' ');
          output.appendChild(line);
          originalLog(...args);
        };
        try {
        \(safeSource)
        } catch (error) {
          const line = document.createElement('pre');
          line.textContent = 'Error: ' + error;
          output.appendChild(line);
        }
        </script></body></html>
        """
    }
}

private struct PreviewWebView: UIViewRepresentable {
    let html: String

    func makeUIView(context: Context) -> WKWebView {
        let view = WKWebView()
        view.loadHTMLString(html, baseURL: nil)
        return view
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {
        uiView.loadHTMLString(html, baseURL: nil)
    }
}
