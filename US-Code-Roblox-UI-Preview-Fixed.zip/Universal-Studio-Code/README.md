# Universal Studio Code — US- Code

A dark-emerald native iPad coding workspace built with SwiftUI.

## Included in this starter build

- Native iPad SwiftUI interface
- Dark emerald theme
- Local project storage (up to 100 projects)
- HTML, JavaScript, Python, Lua and Roblox Luau project templates
- Monospaced editor with line numbers
- Import UTF-8 source files from the Files app
- Export the selected source file back to Files
- Interactive HTML preview powered by WebKit
- JavaScript preview with `console.log` output shown in the page
- Local Roblox GUI preview simulator for common Luau UI scripts, including Frames, labels, buttons, text boxes, scrolling frames, corners, strokes and simple click callbacks
- GitHub Actions workflow that builds an unsigned iOS IPA

## Roblox UI preview — scope and limitations

Press **Run** on a `.lua` or `.luau` file to open the local Roblox GUI simulator. It recognizes common `Instance.new(...)` UI objects and common property assignments, including:

- `ScreenGui`, `Frame`, `TextLabel`, `TextButton`, `TextBox`, `ScrollingFrame`
- `ImageLabel`, `ImageButton`, `UICorner`, `UIStroke`, `UIListLayout`
- Common `UDim2.new`, `UDim2.fromScale`, `UDim2.fromOffset`, `Color3.fromRGB` and `Color3.new` values
- Basic `MouseButton1Click` / `Activated` callbacks that update simple UI properties or print output

Example supported UI script:

```lua
local gui = Instance.new("ScreenGui")
gui.Parent = game:GetService("Players").LocalPlayer:WaitForChild("PlayerGui")

local frame = Instance.new("Frame")
frame.Size = UDim2.new(0, 280, 0, 180)
frame.Position = UDim2.new(0.5, -140, 0.5, -90)
frame.BackgroundColor3 = Color3.fromRGB(25, 45, 35)
frame.Parent = gui

local button = Instance.new("TextButton", frame)
button.Size = UDim2.new(1, -30, 0, 44)
button.Position = UDim2.new(0, 15, 0, 20)
button.Text = "Tap me"
button.MouseButton1Click:Connect(function()
    button.Text = "Clicked!"
end)
```

**This is a GUI preview simulator, not the Roblox engine or a complete Luau interpreter.** It does not execute arbitrary Luau syntax, Roblox services, remote events, player/game state, TweenService animations, physics or networking. Scripts that depend on those features will not behave like they do inside Roblox. The preview is intended to help inspect and interact with common UI-building scripts locally.

Python files remain editable but Python execution is not included. Standard Lua execution is not included; `.lua` files are routed to the same Roblox GUI preview simulator for convenience.

## Repository structure

```text
USCode/
  USCodeApp.swift
  Models/
    CodeLanguage.swift
    CodeFile.swift
    CodeProject.swift
  Storage/
    ProjectStore.swift
  Services/
    CodeFileDocument.swift
  Components/
    CodeEditorView.swift
  Views/
    DashboardView.swift
    NewProjectView.swift
    ProjectEditorView.swift
    HTMLPreviewView.swift
    RobloxPreviewView.swift
.github/workflows/ios-build.yml
project.yml
```

## Build from GitHub on iPad

There are two upload methods:

- **ZIP-extraction workflow:** Upload `Universal-Studio-Code-Repository.zip` to the repository root, then create `.github/workflows/ios-build.yml` using the ZIP-extraction workflow supplied separately. That workflow extracts the archive before running XcodeGen.
- **Extracted source upload:** Upload the contents of this folder to the repository root, keeping the included `.github/workflows/ios-build.yml` at its exact path.

Then open **Actions**, select the build workflow and tap **Run workflow**. Download the IPA artifact after a successful run. The ZIP-extraction workflow produces `US-Code.ipa`; the bundled source-upload workflow produces `US-Code-unsigned.ipa`.

## Installation targets

The workflow produces an **unsigned** IPA. It is a build artifact, not a directly installable signed app. SideStore and AltStore generally re-sign imported apps using their supported workflow. LiveContainer has its own compatibility and signing requirements. A single unsigned artifact is not guaranteed to work identically in all three; capabilities, entitlements and iOS version restrictions can differ.

Never add Apple certificates or provisioning profiles to a public repository. If a future workflow signs the app, use private GitHub Actions secrets and a provisioning profile matching the bundle identifier.

## App identity

- Display name: `US- Code`
- Product name: `US- Code`
- Bundle identifier: `com.uscode.editor` (provisional)
- Minimum deployment target: iOS 16.0

## Current limitations

- This is a starter editor with a limited Roblox GUI simulator, not a full Roblox development environment.
- Syntax highlighting, autocomplete, breakpoints and debugger are not implemented.
- File import currently imports one UTF-8 text file at a time; folder and ZIP import/export are not implemented yet.
- JavaScript runs in WebKit, not Node.js. Node modules and native packages are not available.
