import Foundation

enum CodeLanguage: String, CaseIterable, Identifiable, Codable {
    case html = "HTML"
    case javascript = "JavaScript"
    case python = "Python"
    case lua = "Lua"
    case luau = "Roblox Luau"

    var id: String { rawValue }

    var fileExtension: String {
        switch self {
        case .html: return "html"
        case .javascript: return "js"
        case .python: return "py"
        case .lua: return "lua"
        case .luau: return "luau"
        }
    }

    var starterCode: String {
        switch self {
        case .html:
            return """
            <!doctype html>
            <html>
            <head>
              <meta name="viewport" content="width=device-width, initial-scale=1">
              <title>My page</title>
              <style>
                body { font-family: system-ui; padding: 24px; background: #101b16; color: white; }
                button { padding: 12px 18px; border: 0; border-radius: 10px; background: #10b981; color: #04130d; }
              </style>
            </head>
            <body>
              <h1>Hello, US- Code!</h1>
              <button onclick="document.querySelector('p').textContent = 'It works!'">Tap me</button>
              <p>Interactive preview is ready.</p>
            </body>
            </html>
            """
        case .javascript:
            return "console.log('Hello from JavaScript!');"
        case .python:
            return "print('Hello from Python!')"
        case .lua, .luau:
            return """
            local screenGui = Instance.new("ScreenGui")
            screenGui.Name = "USCodePreview"
            screenGui.Parent = game:GetService("Players").LocalPlayer:WaitForChild("PlayerGui")

            local frame = Instance.new("Frame")
            frame.Size = UDim2.new(0, 280, 0, 180)
            frame.Position = UDim2.new(0.5, -140, 0.5, -90)
            frame.BackgroundColor3 = Color3.fromRGB(25, 45, 35)
            frame.Parent = screenGui

            local corner = Instance.new("UICorner", frame)
            corner.CornerRadius = UDim.new(0, 16)

            local title = Instance.new("TextLabel")
            title.Size = UDim2.new(1, -20, 0, 45)
            title.Position = UDim2.new(0, 10, 0, 12)
            title.BackgroundTransparency = 1
            title.Text = "Hello, Roblox UI!"
            title.TextColor3 = Color3.fromRGB(240, 255, 245)
            title.TextSize = 20
            title.Parent = frame

            local button = Instance.new("TextButton")
            button.Size = UDim2.new(1, -40, 0, 44)
            button.Position = UDim2.new(0, 20, 0, 95)
            button.BackgroundColor3 = Color3.fromRGB(16, 185, 129)
            button.Text = "Tap me"
            button.TextColor3 = Color3.fromRGB(5, 25, 15)
            button.TextSize = 17
            button.Parent = frame

            button.MouseButton1Click:Connect(function()
                title.Text = "Button clicked!"
            end)
            """
        }
    }
}
