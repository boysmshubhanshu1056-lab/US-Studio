import SwiftUI
import WebKit
import UIKit

/// A local, lightweight Roblox GUI preview simulator for common Luau UI scripts.
/// It maps common Instance.new GUI objects and basic properties/events to HTML.
struct RobloxPreviewView: View {
    let source: String
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            RobloxGUIWebView(source: source)
                .background(Color(red: 0.035, green: 0.055, blue: 0.045))
                .navigationTitle("Roblox UI Preview")
                .navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .cancellationAction) {
                        Button("Done") { dismiss() }
                    }
                }
        }
        .preferredColorScheme(.dark)
    }
}

private struct RobloxGUIWebView: UIViewRepresentable {
    let source: String

    func makeUIView(context: Context) -> WKWebView {
        let configuration = WKWebViewConfiguration()
        let webView = WKWebView(frame: .zero, configuration: configuration)
        webView.isOpaque = false
        webView.backgroundColor = UIColor(red: 0.035, green: 0.055, blue: 0.045, alpha: 1)
        webView.scrollView.backgroundColor = webView.backgroundColor
        webView.loadHTMLString(makeHTML(), baseURL: nil)
        return webView
    }

    func updateUIView(_ webView: WKWebView, context: Context) {
        webView.loadHTMLString(makeHTML(), baseURL: nil)
    }

    private func makeHTML() -> String {
        let encoded = Data(source.utf8).base64EncodedString()
        return Self.template.replacingOccurrences(of: "__SOURCE_BASE64__", with: encoded)
    }

    private static let template = #"""
    <!doctype html>
    <html><head><meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <style>
      *{box-sizing:border-box} html,body{margin:0;width:100%;height:100%;overflow:hidden;background:#09140f;color:#ecfff4;font-family:-apple-system,BlinkMacSystemFont,system-ui,sans-serif}
      #top{height:42px;padding:0 12px;display:flex;align-items:center;justify-content:space-between;background:#10251a;border-bottom:1px solid #254735;font-size:12px;color:#b8d8c5}
      #stage{height:calc(100dvh - 42px);width:100%;position:relative;overflow:auto;background:#15191b}
      #gui-root{position:relative;width:100%;height:100%;min-height:100%;overflow:hidden;background:#20242a}
      .gui{position:absolute;box-sizing:border-box;overflow:hidden;min-width:0;min-height:0}
      .label{display:flex;align-items:center;justify-content:center;white-space:pre-wrap;overflow-wrap:anywhere;padding:3px}
      button.gui{font:inherit;color:inherit;cursor:pointer;-webkit-appearance:none}
      input.gui{font:inherit;color:inherit;padding:5px}
      #console{height:100px;max-height:28dvh;overflow:auto;background:#07100b;border-top:1px solid #254735;padding:7px 10px;font:11px ui-monospace,monospace;color:#bce8ca}
      #console .error{color:#ff9d9d} #console .muted{color:#8da897}
      #bottom{height:100px;max-height:28dvh}
      .unsupported{padding:16px;color:#ffd89b;font-size:13px}
    </style></head><body>
    <div id="top"><strong>ROBLOX GUI SIMULATOR</strong><span id="status">Preparing preview…</span></div>
    <div id="stage"><div id="gui-root"></div></div>
    <div id="bottom"><div id="console"><div class="muted">Output / diagnostics</div></div></div>
    <script>
    (()=>{
      const raw=atob('__SOURCE_BASE64__');
      const source=decodeURIComponent(Array.from(raw,c=>'%'+c.charCodeAt(0).toString(16).padStart(2,'0')).join(''));
      const root=document.getElementById('gui-root'), logBox=document.getElementById('console'), status=document.getElementById('status');
      const objects={}, parents={}, events={}, warnings=[];
      function log(message,kind=''){const row=document.createElement('div');row.textContent=String(message);if(kind)row.className=kind;logBox.appendChild(row);logBox.scrollTop=logBox.scrollHeight;}
      function warn(message){warnings.push(message);log('Preview note: '+message,'muted');}
      const clean=source.replace(/--\[\[[\s\S]*?\]\]/g,'').replace(/--[^\n]*/g,'');
      const lines=clean.split(/\r?\n/);
      const classes=['ScreenGui','Frame','TextLabel','TextButton','TextBox','ScrollingFrame','ImageLabel','ImageButton','UICorner','UIStroke','UIListLayout','UIPadding','UIGradient'];
      const newRE=/^\s*(?:local\s+)?([A-Za-z_]\w*)\s*=\s*Instance\.new\s*\(\s*["']([A-Za-z]+)["']\s*(?:,\s*([A-Za-z_]\w*(?:\.[A-Za-z_]\w*)*))?\s*\)/;
      for(const line of lines){const m=line.match(newRE);if(m){if(!classes.includes(m[2])){warn('Unsupported GUI class '+m[2]);continue;}objects[m[1]]={name:m[1],cls:m[2],props:{},el:null};if(m[3])parents[m[1]]=m[3];}}
      if(Object.keys(objects).length===0){
        status.textContent='No supported GUI objects found';
        const msg=document.createElement('div');msg.className='unsupported';msg.textContent='No supported Instance.new GUI objects were found. Try creating a ScreenGui, Frame, TextLabel, TextButton or ScrollingFrame.';root.appendChild(msg);
        log('No previewable GUI instances found.','error');return;
      }
      function parseValue(v){v=v.trim().replace(/;$/,'').trim();
        if(/^(["']).*\1$/.test(v))return v.slice(1,-1).replace(/\\n/g,'\n').replace(/\\"/g,'"').replace(/\\'/g,"'");
        if(v==='true')return true;if(v==='false')return false;if(v==='nil')return null;
        let m=v.match(/^UDim2\.(?:new|fromScale|fromOffset)\s*\((.*)\)$/);if(m){const a=m[1].split(',').map(Number);if(v.includes('fromScale'))return {sx:a[0]||0,ox:0,sy:a[1]||0,oy:0};if(v.includes('fromOffset'))return {sx:0,ox:a[0]||0,sy:0,oy:a[1]||0};return {sx:a[0]||0,ox:a[1]||0,sy:a[2]||0,oy:a[3]||0};}
        m=v.match(/^Color3\.fromRGB\s*\((.*)\)$/);if(m){const a=m[1].split(',').map(Number);return 'rgb('+a.map(x=>Math.max(0,Math.min(255,x))).join(',')+')';}
        m=v.match(/^Color3\.new\s*\((.*)\)$/);if(m){const a=m[1].split(',').map(Number);return 'rgb('+a.slice(0,3).map(x=>Math.round(Math.max(0,Math.min(1,x))*255)).join(',')+')';}
        m=v.match(/^Vector2\.new\s*\((.*)\)$/);if(m)return m[1].split(',').map(Number);
        m=v.match(/^UDim\.new\s*\((.*)\)$/);if(m){const a=m[1].split(',').map(Number);return {scale:a[0]||0,offset:a[1]||0};}
        m=v.match(/^Enum\.\w+\.([\w]+)$/);if(m)return m[1];
        if(/^[-+]?\d+(?:\.\d+)?$/.test(v))return Number(v);
        return v;
      }
      for(const line of lines){
        const m=line.match(/^\s*([A-Za-z_]\w*)\.([A-Za-z_]\w*)\s*=\s*(.*?)\s*;?\s*$/);
        if(m&&objects[m[1]]){
          const value=parseValue(m[3]);
          if(m[2]==='Parent'){if(typeof value==='string'&&objects[value])parents[m[1]]=value;else parents[m[1]]='__ROOT__';}
          else objects[m[1]].props[m[2]]=value;
        }
      }
      function dim(v,axis){if(!v||typeof v!=='object'||!('sx'in v))return '100%';const scale=axis==='x'?v.sx:v.sy,off=axis==='x'?v.ox:v.oy;return `calc(${scale*100}% + ${off}px)`;}
      function applyProps(obj,el){const p=obj.props,c=obj.cls;
        const size=p.Size||{sx:0,ox:(c==='TextLabel'||c==='TextButton'?150:100),sy:0,oy:(c==='TextLabel'||c==='TextButton'?40:100)};
        const pos=p.Position||{sx:0,ox:0,sy:0,oy:0};el.style.width=dim(size,'x');el.style.height=dim(size,'y');el.style.left=dim(pos,'x');el.style.top=dim(pos,'y');
        const anchor=p.AnchorPoint;if(Array.isArray(anchor))el.style.transform=`translate(${-anchor[0]*100}%,${-anchor[1]*100}%)`;
        if(p.BackgroundColor3)el.style.background=p.BackgroundColor3;
        if(p.BackgroundTransparency!==undefined)el.style.background=p.BackgroundTransparency>=1?'transparent':(el.style.background||'rgba(255,255,255,.12)');
        if(p.BorderSizePixel!==undefined)el.style.border=p.BorderSizePixel===0?'none':`${p.BorderSizePixel}px solid #555`;
        if(p.Visible===false)el.style.display='none';if(p.Rotation)el.style.rotate=p.Rotation+'deg';
        if(p.ZIndex!==undefined)el.style.zIndex=p.ZIndex;
        if(p.TextColor3)el.style.color=p.TextColor3;if(p.TextSize)el.style.fontSize=p.TextSize+'px';
        if(p.Font)el.style.fontWeight=/Bold|Heavy|Black/i.test(p.Font)?'700':'400';
        if(p.TextXAlignment)el.style.justifyContent=p.TextXAlignment==='Left'?'flex-start':p.TextXAlignment==='Right'?'flex-end':'center';
        if(p.TextYAlignment)el.style.alignItems=p.TextYAlignment==='Top'?'flex-start':p.TextYAlignment==='Bottom'?'flex-end':'center';
        if(p.TextWrapped)el.style.whiteSpace='pre-wrap';if(p.TextScaled)el.style.fontSize='clamp(10px, 3vw, 24px)';
        if(p.PlaceholderText)el.placeholder=p.PlaceholderText;
        if(p.Text!==undefined){if(c==='TextBox')el.value=p.Text;else el.textContent=p.Text;}
        if(p.Image){el.style.backgroundImage=`url('${p.Image}')`;el.style.backgroundSize='contain';el.style.backgroundRepeat='no-repeat';el.style.backgroundPosition='center';}
        if(p.ClipsDescendants)el.style.overflow='hidden';if(c==='ScrollingFrame')el.style.overflow='auto';
      }
      for(const [name,obj] of Object.entries(objects)){
        if(obj.cls==='UICorner'||obj.cls==='UIStroke'||obj.cls==='UIListLayout'||obj.cls==='UIPadding'||obj.cls==='UIGradient')continue;
        let el;if(obj.cls==='TextButton'||obj.cls==='ImageButton'){el=document.createElement('button');el.type='button';el.className='gui';}
        else if(obj.cls==='TextBox'){el=document.createElement('input');el.className='gui';}
        else {el=document.createElement('div');el.className='gui';}
        if(obj.cls==='TextLabel')el.classList.add('label');if(obj.cls==='TextButton')el.classList.add('label');
        obj.el=el;el.dataset.object=name;applyProps(obj,el);
      }
      // Apply UI decorators to their parent.
      for(const [name,obj] of Object.entries(objects)){
        const parentName=parents[name], parent=objects[parentName];if(!parent||!parent.el)continue;
        if(obj.cls==='UICorner'){parent.el.style.borderRadius=(obj.props.CornerRadius&&obj.props.CornerRadius.offset||10)+'px';}
        if(obj.cls==='UIStroke'){parent.el.style.border=`${obj.props.Thickness||1}px solid ${obj.props.Color||'#ffffff'}`;}
        if(obj.cls==='UIListLayout'){
          parent.el.style.display='flex';parent.el.style.flexDirection=obj.props.FillDirection==='Horizontal'?'row':'column';
          parent.el.style.gap=(obj.props.Padding&&obj.props.Padding.oy||8)+'px';parent.el.style.alignItems='stretch';parent.el.dataset.hasListLayout='1';
        }
      }
      // Build the hierarchy. ScreenGui is represented by the viewport root.
      const screenGuis=Object.entries(objects).filter(([n,o])=>o.cls==='ScreenGui');
      const guiRoot=screenGuis.length?screenGuis[0][0]:null;
      for(const [name,obj] of Object.entries(objects)){
        if(!obj.el)continue;let parentName=parents[name];
        if(obj.cls==='ScreenGui'||parentName==='__ROOT__'||!parentName){root.appendChild(obj.el);if(obj.cls==='ScreenGui'){obj.el.style.position='absolute';obj.el.style.inset='0';obj.el.style.width='100%';obj.el.style.height='100%';obj.el.style.pointerEvents='none';}}
        else if(objects[parentName]&&objects[parentName].el){objects[parentName].el.appendChild(obj.el);if(objects[parentName].el.dataset.hasListLayout==='1'){obj.el.style.position='relative';obj.el.style.left='auto';obj.el.style.top='auto';obj.el.style.flexShrink='0';}}
        else {root.appendChild(obj.el);}
        if(obj.cls==='TextButton'||obj.cls==='ImageButton')obj.el.style.pointerEvents='auto';
      }
      // ScreenGui descendants need to remain interactive while the GUI container ignores pointer events.
      for(const obj of Object.values(objects)){if(obj.el&&obj.cls!=='ScreenGui')obj.el.style.pointerEvents='auto';}
      // Bind common click/activated handlers. This intentionally supports simple UI callbacks, not all Luau.
      const eventRE=/([A-Za-z_]\w*)\.(?:MouseButton1Click|Activated|MouseButton1Down)\s*:\s*Connect\s*\(\s*function\s*\([^)]*\)([\s\S]*?)\bend\s*\)/g;
      let match;while((match=eventRE.exec(clean))!==null){const obj=objects[match[1]];if(!obj||!obj.el)continue;const body=match[2];obj.el.addEventListener('click',()=>runCallback(body));}
      function runCallback(body){
        const statements=body.split(/[\n;]/).map(s=>s.trim()).filter(Boolean);
        for(let statement of statements){
          let m=statement.match(/^print\s*\((.*)\)$/);if(m){log(parseValue(m[1]));continue;}
          m=statement.match(/^([A-Za-z_]\w*)\.([A-Za-z_]\w*)\s*=\s*(.*?)\s*$/);
          if(m&&objects[m[1]]){const target=objects[m[1]],prop=m[2];let value;
            if(m[3]===`not ${m[1]}.${prop}`)value=!target.props[prop];
            else if(m[3]==='not '+m[1])value=!target.props[prop];
            else value=parseValue(m[3]);
            target.props[prop]=value;
            if(prop==='Text'&&target.el)target.el.textContent=value;
            if(prop==='Visible'&&target.el)target.el.style.display=value?'':'none';
            if(prop==='BackgroundColor3'&&target.el)target.el.style.background=value;
            if(prop==='TextColor3'&&target.el)target.el.style.color=value;
          }
        }
      }
      // Render notes for API calls that need the Roblox engine.
      if(/game:GetService|Players\.LocalPlayer|workspace|TweenService|UserInputService/.test(clean))warn('Roblox services/gameplay APIs are not emulated; this preview focuses on GUI creation.');
      if(/:Connect\s*\(/.test(clean)&&!Object.values(objects).some(o=>o.el&&o.el.onclick!==undefined)){}
      status.textContent=Object.keys(objects).length+' GUI objects';
      log('Rendered supported Roblox GUI objects. Tap preview buttons to test supported click handlers.');
      log('This is a local GUI simulator, not the Roblox engine.','muted');
    })();
    </script></body></html>
    """#
}
