import SwiftUI
import UniformTypeIdentifiers

struct ProjectEditorView: View {
    @EnvironmentObject private var store: ProjectStore
    let projectID: UUID

    @State private var selectedFileID: UUID?
    @State private var showingImporter = false
    @State private var showingExporter = false
    @State private var showingPreview = false
    @State private var showingRuntimeNotice = false
    @State private var importError: String?

    private var project: CodeProject? { store.project(withID: projectID) }
    private var selectedFile: CodeFile? {
        guard let project else { return nil }
        return project.files.first { $0.id == selectedFileID } ?? project.files.first
    }
    private var editorBinding: Binding<String> {
        Binding(
            get: { selectedFile?.content ?? "" },
            set: { value in
                guard let file = selectedFile else { return }
                store.updateFile(projectID: projectID, fileID: file.id, content: value)
            }
        )
    }

    var body: some View {
        VStack(spacing: 0) {
            if let project {
                HStack {
                    VStack(alignment: .leading, spacing: 3) {
                        Text(project.name).font(.headline)
                        Text(selectedFile?.name ?? "No file").font(.caption).foregroundStyle(.secondary)
                    }
                    Spacer()
                    Menu {
                        Button("Import file", systemImage: "square.and.arrow.down") { showingImporter = true }
                        Button("Export current file", systemImage: "square.and.arrow.up") { showingExporter = true }
                    } label: {
                        Image(systemName: "ellipsis.circle").font(.title2)
                    }
                }
                .padding()

                if project.files.count > 1 {
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack {
                            ForEach(project.files) { file in
                                Button { selectedFileID = file.id } label: {
                                    Text(file.name).font(.caption.monospaced())
                                        .padding(.horizontal, 12).padding(.vertical, 8)
                                        .background(selectedFile?.id == file.id ? Color.green.opacity(0.2) : Color.white.opacity(0.06), in: Capsule())
                                }
                            }
                        }
                        .padding(.horizontal)
                    }
                    .padding(.bottom, 8)
                }

                CodeEditorView(text: editorBinding).frame(maxWidth: .infinity, maxHeight: .infinity)

                HStack {
                    Text(selectedFile?.language.rawValue ?? project.language.rawValue)
                        .font(.caption).foregroundStyle(.secondary)
                    Spacer()
                    Button { runProject() } label: {
                        Label("Run", systemImage: "play.fill")
                            .font(.subheadline.bold()).padding(.horizontal, 20).padding(.vertical, 11)
                            .background(Color.green, in: Capsule()).foregroundStyle(.black)
                    }
                }
                .padding().background(Color.black.opacity(0.25))
            } else {
                Text("Project not found").foregroundStyle(.secondary)
            }
        }
        .background(Color(red: 0.043, green: 0.09, blue: 0.067))
        .navigationBarTitleDisplayMode(.inline)
        .fileImporter(isPresented: $showingImporter, allowedContentTypes: [.item], allowsMultipleSelection: false) { result in
            importFile(result)
        }
        .fileExporter(
            isPresented: $showingExporter,
            document: CodeFileDocument(text: selectedFile?.content ?? ""),
            contentType: exportType,
            defaultFilename: selectedFile?.name ?? "source.txt"
        ) { _ in }
        .sheet(isPresented: $showingPreview) {
            if let file = selectedFile {
                if file.language == .luau || file.language == .lua {
                    RobloxPreviewView(source: file.content)
                } else {
                    HTMLPreviewView(source: file.content, language: file.language)
                }
            }
        }
        .alert("Runtime unavailable", isPresented: $showingRuntimeNotice) {
            Button("OK", role: .cancel) {}
        } message: {
            Text("Run preview is available for HTML, JavaScript and supported Roblox Luau GUI scripts. Python and standard Lua execution are not included in this build.")
        }
        .alert("Import failed", isPresented: Binding(
            get: { importError != nil },
            set: { if !$0 { importError = nil } }
        )) {
            Button("OK", role: .cancel) { importError = nil }
        } message: {
            Text(importError ?? "Unknown error")
        }
    }

    private var exportType: UTType {
        UTType(filenameExtension: selectedFile?.fileExtension ?? "txt") ?? .plainText
    }

    private func runProject() {
        guard let file = selectedFile else { return }
        if file.language == .html || file.language == .javascript || file.language == .luau || file.language == .lua {
            showingPreview = true
        } else {
            showingRuntimeNotice = true
        }
    }

    private func importFile(_ result: Result<[URL], Error>) {
        do {
            guard let url = try result.get().first else { return }
            let accessed = url.startAccessingSecurityScopedResource()
            defer { if accessed { url.stopAccessingSecurityScopedResource() } }
            let data = try Data(contentsOf: url)
            guard let content = String(data: data, encoding: .utf8) else {
                throw NSError(domain: "USCodeImport", code: 1, userInfo: [NSLocalizedDescriptionKey: "The selected file is not UTF-8 text."])
            }
            let ext = url.pathExtension.lowercased()
            let language: CodeLanguage
            switch ext {
            case "html", "htm": language = .html
            case "js", "mjs": language = .javascript
            case "py": language = .python
            case "lua": language = .lua
            case "luau": language = .luau
            default: language = project?.language ?? .html
            }
            let file = CodeFile(name: url.lastPathComponent, language: language, content: content)
            store.addFile(projectID: projectID, file: file)
            selectedFileID = file.id
        } catch {
            importError = error.localizedDescription
        }
    }
}
